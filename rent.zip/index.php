<!DOCTYPE html>
<html>
<head>
	<title>index</title>
	<style type="text/css">
		.bg{
			background-image:  url("image/rent1.jpg");
			background-size: contain;
			width: 1070px;
			height: 500px;
			border: 1px solid block;
			/*color: pink;*/
			resize: both;
			overflow: scroll;
		}
		h2{
			text-align: center;
			color: white;
			font-size: 40px;
			font-family: fantasy;
			font-weight: bold;
		}
		h3{
			text-align: center;
			color: white;
			font-size: 30px;
			font-family: verdana;
			font-weight: italic;

		}
	</style>
</head>
<body>
	<?php include('i-header.php'); ?>
<div class="bg" >
		 <h2>  <i>WELCOME TO OXYGEN PLAZA INFORMATION SYSTEM</i> </h2>
		 <h3> We offer the best services for our customers</h3>
		
	</div>

</body>
</html>