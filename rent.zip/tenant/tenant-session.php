<?php 

if (!isset($_SESSION['email'])) {
	header('Location: tenant-login.php');
}



 ?>