<?php 

$con = mysqli_connect('localhost','root','','rental') or die(mysqli_error($con));

?>