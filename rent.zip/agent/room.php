<?php 
session_start();
include('agent-session.php'); 
require '../dbcontroller.php';
include('a-header.php');
 ?>

<!DOCTYPE html>
	
<head>
<title>Room</title>
<style type="text/css">
	form{
		 width: 60%;
		margin: 2px auto;
		border-radius: 10px;
		background: white;
		color: black;
		padding: 2px;
		text-align: justify;
		opacity: 0.7;
	}
	input[type=text]{
		width: 70%;
		height: 20px;
		padding: 20px 20px;
		margin: 8px 0;
		box-sizing: border-box;
		border: 2px solid steelblue;
		border-radius: 8px;
		font-size: 16px;
		margin-left: 15%;


	}
	input[type=number]{
		width: 70%;
		height: 20px;
		padding: 20px 20px;
		margin: 8px 0;
		box-sizing: border-box;
		border: 2px solid steelblue;
		border-radius: 4px;
		font-size: 16px;
		margin-left: 15%;


	}
	input[type=submit]{
		size: 20px;
		background-color: #4CAF50;
		border: 2px solid black;
		padding: 5px 25px;
		text-decoration: none;
		margin: 2px 2px;
		cursor: pointer;
		border-radius: 6px;
		text-align: center;
		font-size: 16px;
		margin-left: 40%;
	}
	button{
		size: 20px;
		background-color: #FFA500;
		border: 2px solid black;
		padding: 5px 25px;
		margin: 2px 2px;
		cursor: pointer;
		border-radius: 8px;
	}
	 label{
	 	margin-left: 15%;
	 }
	h2{
		padding: 2px;
		margin: 2px;
		text-align: center;
	}
	.bg{
		background-image: url("../image/rent1.jpg");
		background-size: contain;
		width: 1070px;
		height: 400px;
		border: 1px solid block;
		/*color: pink;*/
		resize: both;
		overflow: scroll;
	}
	button a{
		text-decoration: none;
		font-weight: bold;
		font-size: 20px;

	}
</style>
</head>
<body>
<div class="bg" >
	
<form name="frmRegistration" method="post" action="rom.php" > 
	<h2>Room Information Form</h2>


<label for="type" >Room Number</label><br> 
 <select name="rcode" style="color: black; width:70%; padding: 10px; border: 2px solid steelblue; border-radius: 4px;margin-left: 15%;">>
	<option>1</option>
	<option>2</option>
	<option>3</option>
	<option>4</option>
	<option>5</option>
	<option>6</option>
	<option>7</option>
	<option>8</option>
	<option>9</option>
	<option>10</option>
	<option>11</option>
	<option>12</option>
	<option>13</option>
	<option>14</option>
	<option>15</option>
	<option>16</option>
	<option>17</option>
	<option>18</option>
	<option>19</option>
	<option>20</option>
	<option>21</option>
	<option>22</option>
	<option>23</option>
	<option>24</option>
	<option>25</option>
	<option>26</option>
	<option>27</option>
	<option>28</option>
	<option>29</option>
	<option>30</option>
	<option>31</option>
	<option>32</option>
	<option>33</option>
	<option>34</option>
	<option>35</option>
	<option>36</option>
	<option>37</option>
	<option>38</option>
	<option>39</option>
	<option>40</option>
	<option>41</option>
	<option>42</option>
	<option>43</option>
	<option>44</option>
	<option>45</option>
	<option>46</option>
	<option>47</option>
	<option>48</option>
</select>
<label for="type" > Room Type</label> 
<br> <select name="type" style="color: black; width:70%; padding: 10px; border: 2px solid steelblue; border-radius: 4px;margin-left: 15%;">>
	<option>Tiled</option>
	<option>Untiled</option>
</select><br>
<label for="floor" > Floor</label> 
<br> <select name="floor" style="color: black; width:70%; padding: 10px; border: 2px solid steelblue; border-radius: 4px;margin-left: 15%;">>
	<option>First</option>
	<option>Second</option>
	<option>Third</option>
	<option>Fouth</option>
	<option>Fifth</option>
	<option>Sixth</option>
	<option>Seventh</option>
	<option>Eigth</option>
	<option>Ninth</option>
	<option>Eleventh</option>
</select><br>
<label for="cost" >Cost</label> 
<br> <select name="cost" style="color: black; width:70%; padding: 10px; border: 2px solid steelblue; border-radius: 4px;margin-left: 15%;">>
	<option>8000</option>
	<option>10000</option>
</select><br>
<label for="status" >Status</label> 
<br> <select name="status" style="color: black; width:70%; padding: 10px; border: 2px solid steelblue; border-radius: 4px;margin-left: 15%;">>
	<option>Vacant</option>
	<option>Occupied</option>
</select><br>

<input type="submit" name="submit" value="Submit" class="btn-in">
 <button> <a href="agent-home.php">Cancel</a></button>
</form>
</div>
</bod/>
</html>
